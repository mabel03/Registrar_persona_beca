</div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div class="redes">
        <center>
        Github: @Mabel03
        <br>
        Linkedin: @Mabel Cabrera
        <br>
        Gmail: mabel.larosa027@gmail.com
        <br>
        Derechos reservado <?= date('Y'); ?>
        </center>

    </div>    
</body>
</html>